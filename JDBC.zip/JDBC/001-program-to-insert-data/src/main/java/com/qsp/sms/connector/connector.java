package com.qsp.sms.connector;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class connector {
	public static void main(String[] args) {
		try {
			Class.forName("org.postgresql.Driver");
			Connection connection = DriverManager.getConnection("jdbc:postgresql://localhost:5432/first_db" ,"postgres","root");
			Statement statement = connection.createStatement();		
			//step 4
			statement.execute("INSERT INTO student VALUES(1,'Santosh')");
			statement.execute("INSERT INTO student VALUES(3,'Sas')");
			
			//step 5
			connection.close();
			System.out.println("Successfull");
				} catch (ClassNotFoundException e) {
					
					e.printStackTrace();
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		

}}
