package com.qsp.sms.batexpreparestmt;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Properties;

import org.postgresql.Driver;

public class  Batchexusingprepaestmt{

	public static void main(String[] args) {
		Connection connection=null;
		try {
			Driver driver = new Driver();
			DriverManager.registerDriver(driver);
			
			FileInputStream fileInputStream = new FileInputStream("dbconfig.properties");
			Properties properties = new Properties();
			properties.load(fileInputStream);
			
			 connection = DriverManager.getConnection("jdbc:postgresql://localhost:5432/first_db", properties);
			
			String query="INSERT INTO student VALUES(?,?)";
			PreparedStatement prepareStatement = connection.prepareStatement(query);
			prepareStatement.setInt(1, 9);
			prepareStatement.setString(2, "kitretshu");
			
			prepareStatement.execute();		
			 
			 
			 
			 
			 
			 
			
			System.out.println("DATA INSERTED SUCCESSFULLY");
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();	
		}
		finally {
			if (connection!=null) {
				try {
					connection.close();
				} catch (Exception e2) {
				}
			}
		}
	}

}

//
//import java.io.FileInputStream;
//import java.io.FileNotFoundException;
//import java.io.IOException;
//import java.sql.Connection;
//import java.sql.DriverManager;
//import java.sql.PreparedStatement;
//import java.sql.SQLException;
//import java.util.Properties;
//
//import org.postgresql.Driver;
//
//public class Batchexusingprepaestmt {
//
//	public static void main(String[] args) {
//
//		Driver driver = new Driver();
//		try {
//			DriverManager.registerDriver(driver);
//			FileInputStream fileinputstream = new FileInputStream("dbconfig.properties");
//			Properties properties = new Properties();
//			 properties.load(fileinputstream);
//			Connection connection = DriverManager.getConnection("jdbc:postgresql://localhost:5432/first_db", properties);
//			 String query="Insert into student values(?,?);";
//			PreparedStatement prepareStatement = connection.prepareStatement(query);
//			 prepareStatement.setInt(1,9);
//			 prepareStatement.setString(2, "kitretshu");
//				
//				prepareStatement.execute();		
//				System.out.println("DATA INSERTED SUCCESSFULLY");
//		} catch (SQLException e) {
//			e.printStackTrace();
//		} catch (FileNotFoundException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		} catch (IOException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//	finally {
//		if (connection!=null) {
//			try {
//				
//				connection.close();
//			} catch (Exception e2) {
//			}
//			
//		}
//	}
//	}
//
//}
