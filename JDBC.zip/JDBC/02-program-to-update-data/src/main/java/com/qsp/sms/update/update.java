package com.qsp.sms.update;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class update {
//
	public static void main(String[] args) {
		//Step1:Load or register Driver
		try {
			Class.forName("org.postgresql.Driver");
			// Step 2:Establish connection
			try {
				Connection connection = DriverManager.getConnection("jdbc:postgresql://localhost:5432/first_db" ,"postgres","root");
				// step 3: creation of statement
				Statement statement = connection.createStatement();
				//step 4: execution of statement
				statement.execute("update  student set s_name='megastar' where s_id=9");
				// step 5 close the connection
				connection.close();
				System.out.println("Udate sucessfully");
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
