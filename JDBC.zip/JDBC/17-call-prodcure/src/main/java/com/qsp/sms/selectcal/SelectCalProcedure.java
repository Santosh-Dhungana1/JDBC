package com.qsp.sms.selectcal;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Types;
import java.util.Properties;

import org.postgresql.Driver;

public class SelectCalProcedure {

	public static void main(String[] args) {
		Connection	connection=null;

		Driver driver = new Driver();
		try {
			DriverManager.registerDriver(driver);
			FileInputStream fileinputsream = new FileInputStream("dbconfig.properties");
			Properties properties = new Properties();
			properties.load(fileinputsream);
			Connection connection1 = DriverManager.getConnection("jdbc:postgresql://localhost:5432/first_db", properties);
			CallableStatement callablestaement= connection1 .prepareCall("call fetch_student(?,?,?);");
			callablestaement.setInt(1, 9);
			callablestaement.registerOutParameter(2, Types.NUMERIC);
			callablestaement.registerOutParameter(3, Types.VARCHAR);
			callablestaement.execute();
			System.out.println("id :"+ callablestaement.getBigDecimal(2) );
			System.out.println("name:"+callablestaement.getString(3));
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (FileNotFoundException e) {
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			if (connection!=null) {
				try {
					connection.close();
					
				} catch (Exception e2) {
					// TODO: handle exception
				}
				
			}
		}
	}

}

