package com.qsp.sms.model;

public class ShopModel {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
