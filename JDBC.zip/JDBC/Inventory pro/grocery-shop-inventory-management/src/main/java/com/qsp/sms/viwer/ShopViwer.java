package com.qsp.sms.viwer;

public class ShopViwer {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
