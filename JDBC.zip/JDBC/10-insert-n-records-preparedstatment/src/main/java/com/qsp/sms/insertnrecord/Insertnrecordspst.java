package com.qsp.sms.insertnrecord;

  import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;
import java.util.Scanner;

import org.postgresql.Driver;

public class Insertnrecordspst {

	public static void main(String[] args) {
		//step 1
		Driver driver = new Driver();
		try {
			DriverManager.registerDriver(driver);
			//step 2
			FileInputStream fileinputstream = new FileInputStream("dbconfig.properties");
			Properties properties = new Properties();
			properties.load(fileinputstream);
			Connection connection = DriverManager.getConnection("jdbc:postgresql://localhost:5432/first_db", properties);
			// step 3
		String query="Insert into student Values(?,?);";
			PreparedStatement preparedStatement = connection.prepareStatement(query);
			 preparedStatement.setInt(1, 6);
			 preparedStatement.setString(2, "Smith");
			boolean flag=true;
			byte loop=1;
		Scanner scanner = new Scanner(System.in);   
		do { 
			int id=0;
			String name=null;
			System.out.println("Enter id : ");
			id=scanner.nextInt();
			scanner.nextLine();
			System.out.println("Enter name: ");
			name=scanner.nextLine();
		//	statement.execute("Insert into student values("+id+",'"+name+"');");
			System.out.println("1-yes or 0-no");
			loop=scanner.nextByte();
			if (loop==0) {
				
				flag=false;
				
			}
			
			
		} while (flag);
		connection.close();
		System.out.println("inserted");
			
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		

	}

}


