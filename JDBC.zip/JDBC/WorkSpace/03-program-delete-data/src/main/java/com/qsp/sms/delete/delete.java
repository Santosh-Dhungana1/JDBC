package com.qsp.sms.delete;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class delete {
	public static void main(String[] args) {
		try {
			Class.forName("org.postgresql.Driver");
			try {
				Connection connection = DriverManager.getConnection("jdbc:postgresql://localhost:5432/first_db" ,"postgres","root");
				Statement statement = connection.createStatement();
				statement.execute("delete from student where name='megastar'");
				connection.close();
				System.out.println("Successfully deleted");
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
