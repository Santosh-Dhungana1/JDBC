package com.qsp.sms.executeupdate;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class Executeupdate {

	public static void main(String[] args) {

		try {
			//step 1
			Class.forName("org.postgresql.Driver");
			//step 2
			Connection connection = DriverManager.getConnection("jdbc:postgresql://localhost:5432/first_db","postgres","root");
			//step 3
			Statement statement = connection.createStatement();
			//step 4
			int update = statement.executeUpdate(" update  student set name='megastar' where id=1");
			System.out.println(update);
			//step 5
			connection.close();
			
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

}
