package com.qsp.sms.closeconnection;

public class CloseConnection {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
