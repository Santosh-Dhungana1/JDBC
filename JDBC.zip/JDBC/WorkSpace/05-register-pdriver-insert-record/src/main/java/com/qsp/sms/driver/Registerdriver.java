package com.qsp.sms.driver;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

import org.postgresql.Driver;

public class Registerdriver {

	public static void main(String[] args) {
		//step1:register driver
		try {
			Driver driver = new Driver();
			DriverManager.registerDriver(null);
			//step 2:
			
			 Connection connection = DriverManager.getConnection("jdbc:postgresql://localhost:5432/first_db" ,"postgres","root");
			 //step 3:creation of statement
			 Statement statement = connection.createStatement();
			 //step 4
			 statement.execute(null)

			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}

	}

}
