package com.qsp.shop.view;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;

import com.qsp.shop.controller.ShopController;
import com.qsp.shop.model.Product;

public class ShopView {
	static Scanner myInput = new Scanner(System.in);
	static Product product = new Product();
	static ShopController shopController = new ShopController();
	
	public static void main(String[] args) throws SQLException {
		do {
			System.out.println("Select operation to perfrom: ");
			System.out.println("1.Add product\n2.Remove product\n3.Update product details\n4.Fetch product\n0.Exit");
			System.out.print("Enter digit respective to desired option: ");
			int userInput = myInput.nextInt();
			myInput.nextLine();
			switch (userInput) {
			case 0:
				myInput.close();
				System.out.println("----------------------------EXITED----------------------------");
				System.exit(0);

				break;
			case 1:
				System.out.println("How many product \n1.Single product \n2.multiple product");
				int productCount = myInput.nextInt();
				if (productCount == 1) {
					System.out.println("Enter product id: ");
					int i_p_d = myInput.nextInt(); // i_p_id--- input p id
					myInput.nextLine();
					System.out.println("Enter product name: ");
					String i_p_name = myInput.nextLine();
					System.out.println("Enter price: ");
					int i_p_price = myInput.nextInt();
					myInput.nextLine();
					System.out.println("Enter quantity: ");
					int i_p_quantity = myInput.nextInt();
					myInput.nextLine();
					boolean i_p_availability = false;
					if (i_p_quantity > 0) {
						i_p_availability = true;
					}
					if ((shopController.addproduct(i_p_d, i_p_name, i_p_price, i_p_quantity, i_p_availability)) != 0) {
						System.out.println("Product added");
						System.out.println();
					} else {
						System.out.println("Product not added");
						System.out.println();
					}

				}
				else{
					boolean toCoutinue=true;
				ArrayList<Product> products = new ArrayList();

				do {
					Product product = new Product();
					System.out.println("Enter id :");
					product.setP_id(myInput.nextInt());
					myInput.nextLine();
					System.out.println("Enter name :");
					product.setP_name(myInput.nextLine());
					System.out.println("Enter price :");
					product.setP_price(myInput.nextInt());
					//1
					myInput.nextInt();
					System.out.println("Enter quantity :");
					int quantity =myInput.nextInt();							//      WHY
					product.setP_quantity(quantity);
					myInput.nextLine();
					
					boolean i_p_availability=false;
					if (quantity>0) {
						i_p_availability=true;
					}
					product.setAvailability(i_p_availability);
				products.add(product);
				System.out.println("press 1 to countinue add product else press 0 to stop");
				int toAdd=myInput.nextInt();
				if (toAdd==0) {
					toCoutinue=false;
				}
				} while (toCoutinue);
			}
//				
//				

				break;
			case 2:
				
				//
				System.out.println("Enter product id to remove");
				int producttoremove=myInput.nextInt();
				myInput.nextLine();
				
				if (shopController.removeProduct(producttoremove)!=0) {
					System.out.println("ha deleted");
				} else {
					System.out.println("not exeist id deleted");
				} 
				
				break;
			case 3:
				//
				System.out.println("Enter product id to remove");
				int producttoupdate=myInput.nextInt();
				myInput.nextLine();
				ResultSet Product=shopController.fetchProduct(producttoupdate);
				 
				if (Product.next()) {
					System.out.println("What do you want to update?");
					System.out.println("1.Name\n2.Price\n3.Quantity");
					System.out.println("Enter no. respective to desired option: ");
					byte updateOption = myInput.nextByte();
					myInput.nextLine();
					switch (updateOption) {
					case 1:
						System.out.println("Enter Name to update");
						String nameToUpdate=myInput.nextLine();
						if (shopController.updateProductname(producttoupdate, nameToUpdate)) {
							System.out.println("Record update");
						} else {
							System.out.println("Record not updated");

						}
								
						
						
						break;
case 2:
	System.out.println("Enter Price to update:");
	int priceToUpdate=myInput.nextInt();
	if (shopController.priceToUpdate=myInput.nextLine())) {
		
	} else {

	}
	
						
						break;
case 3:
	
	break;
	

					default:
						System.out.println("Invalid selection");
						break;
					}
					
				} else {
					System.out.println("Product with given id does not exist");
				}
				break;
			case 4:
				//4
				System.out.println("Enter product id to fetch");
				int producttofind=myInput.nextInt();
				myInput.nextLine();
				ResultSet fetchProduct=shopController.fetchProduct(producttofind);
				boolean next = false;
				try {
					next = fetchProduct.next();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				if (next) {
					System.out.println("PRODUCT DETAILS :");
					System.out.println("id : "+fetchProduct.getInt(1));
					System.out.println("id : "+fetchProduct.getString(2));
					System.out.println("id : "+fetchProduct.getInt(3));
					System.out.println("id : "+fetchProduct.getInt(4));
					if (fetchProduct.getBoolean(5)) {
						System.out.println("avaiblitity : Avaiable");
					} else {
						System.out.println("avaiblitity :  not Avaiable");
					}
				} else {
					System.out.println("product id : "+producttofind+"does not exist.");
					System.out.println();
				}
				break;

			default:
				System.out.println("--------------------------INVALID SECTION----------------------------");
				break;
			}
		} while (true);
	}
	
	
}


