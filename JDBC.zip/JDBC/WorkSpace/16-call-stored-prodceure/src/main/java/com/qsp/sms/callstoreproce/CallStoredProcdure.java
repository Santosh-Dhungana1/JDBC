package com.qsp.sms.callstoreproce;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import org.postgresql.Driver;

public class CallStoredProcdure {

	@SuppressWarnings("null")
	public static void main(String[] args) {
		Driver driver = new Driver();
		Connection	connection=null;
try {
	DriverManager.registerDriver(driver);
	FileInputStream fileinputstream = new FileInputStream("dbconfig.properties");
	Properties properties = new Properties();
	 properties.load(fileinputstream);
	 DriverManager.getConnection("dbc:postgresql://localhost:5432/first_db", properties);
	CallableStatement callablestament = connection.prepareCall("CALL insert_students(?,?);");
	callablestament.setInt(1, 4);
	callablestament.setString(2,"cnccnc");
	callablestament.execute();
} catch (SQLException e) {
	e.printStackTrace();
} catch (FileNotFoundException e) {
	// TODO Auto-generated catch block!
	e.printStackTrace();
} catch (IOException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}
finally {
	if (connection!=null) {
		try {
			connection.close();
			
		} catch (Exception e2) {
			// TODO: handle exception
		}
		
	}
}
		
	}

	private static void CallableStatement(String string) {
		// TODO Auto-generated method stub
		
	}

}
