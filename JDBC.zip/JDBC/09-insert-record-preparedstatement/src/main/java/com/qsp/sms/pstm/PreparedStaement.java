package com.qsp.sms.pstm;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Properties;

import org.postgresql.Driver;

public class PreparedStaement {

	public static void main(String[] args) {
		
try {//
	Driver driver = new Driver();
	DriverManager.registerDriver(driver);
	//establish connection
	FileInputStream fileinputstream = new FileInputStream("dbconfig.properties");
	Properties properties = new Properties();
	properties.load(fileinputstream);
	Connection connection = DriverManager.getConnection("jdbc:postgresql://localhost:5432/first_db", properties);
	//Step 3
	String query="Insert into student Values(?,?);";
	PreparedStatement preparedStatement = connection.prepareStatement(query);
	 preparedStatement.setInt(1, 6);
	 preparedStatement.setString(2, "Smith");
	 //Step 4
	 preparedStatement.execute();
	 //step 5
	connection.close();
	
} catch (SQLException e) {
	e.printStackTrace();
} catch (FileNotFoundException e) {
	e.printStackTrace();
} catch (IOException e) {
	e.printStackTrace();
}		

	}

}
