package com.qsp.sms.read;

import java.sql.Connection; 
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class read {
	public static void main(String[] args) {
		
			//Step1:Load or register Driver
			try {
				Class.forName("org.postgresql.Driver");
				// Step 2:Establish connection
				try {
					Connection connection = DriverManager.getConnection("jdbc:postgresql://localhost:5432/first_db","postgres","root");
					// step 3: creation of statement
					Statement statement = connection.createStatement();
					//step 4: execution of statement
					ResultSet resultSet = statement.executeQuery("Select * From student where s_id=1");
					while(resultSet.next())
					{
						System.out.println(resultSet.getInt(1));
						System.out.println(resultSet.getString(2));
					}
					
					
					
					// step 5 close the connection
					connection.close();
					System.out.println(" sucessfully");
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			
				
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}


