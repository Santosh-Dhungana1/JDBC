package com.qsp.sms.batchexcution;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

public class Batchexcution {

	public static void main(String[] args) {
		try {
			Class.forName("org.postgresql.Driver");
			FileInputStream  fileinputstream = new FileInputStream("dbconfig.properties");
			Properties properties= new Properties();
			properties.load(fileinputstream);
			Connection connection = DriverManager.getConnection("jdbc:postgresql://localhost:5432/first_db", properties);
			Statement statement = connection.createStatement();
			statement.addBatch("Insert into student values(1,'askji')");
			statement.addBatch("Insert into student values(2,'aman')");
			statement.addBatch("Insert into student values(3,'shivam')");
			int[] executeBatch = statement.executeBatch();
			for (int i = 0; i < executeBatch.length; i++) {
				System.out.println("No of row affected: "+ executeBatch[i]);
				
			}
			connection.close();
			
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
