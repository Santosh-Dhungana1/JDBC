package qsp.com.sms.cbp;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

public class Stringproperties {

	public static void main(String[] args) {
		try {
			Class.forName("org.postgresql.Driver");
			FileInputStream fileinputstream = new FileInputStream("dbconfig.properties");
			Properties properties = new Properties();
			properties.load(fileinputstream);
			Connection connection = DriverManager.getConnection("jdbc:postgresql://localhost:5432/first_db", properties);
			Statement statement = connection.createStatement();
			statement.execute("INSERT INTO student VALUES(2,'San')");
			connection.close();
			System.out.println("inserted");
		} catch (ClassNotFoundException e) {
			
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
	