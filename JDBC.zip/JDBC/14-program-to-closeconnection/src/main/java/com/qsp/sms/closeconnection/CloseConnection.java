package com.qsp.sms.closeconnection;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

import org.postgresql.Driver;

public class CloseConnection {

	public static void main(String[] args) {
		Connection connection=null;
		try {
			Driver driver = new Driver();
			DriverManager.registerDriver(driver);
			
			FileInputStream fileInputStream = new FileInputStream("dbconf.properties");
			Properties properties = new Properties();
			properties.load(fileInputStream);
			
			connection = DriverManager.getConnection("jdbc:postgresql://localhost:5432/first_db", properties);
			
			Statement statement = connection.createStatement();
			
			statement.execute("INSERT INTO student VALUES(9,'mutagorira') ");
			
			System.out.println("Data inserted");
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
				if (connection!=null) {
					try {
						connection.close();
					} catch ( SQLException e) {
						
					}
				
			}
		}
	}



	}


