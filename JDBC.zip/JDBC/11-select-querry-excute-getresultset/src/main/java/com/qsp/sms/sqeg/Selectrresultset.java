package com.qsp.sms.sqeg;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Selectrresultset {

	public static void main(String[] args) {

		try {
			Class.forName("org.postgresql.Driver");
			//step 2
			try {
				Connection connection = DriverManager.getConnection("jdbc:postgresql://localhost:5432/first_db","postgres","root");
				//step 3
				Statement statement = connection.createStatement();
				//step 4
				boolean execute = statement.execute("select * from student");
				if (execute) {
					System.out.println("Data exist");
					ResultSet resultSet = statement.getResultSet();
					while (resultSet.next()) {
						System.out.println("id:"+resultSet.getInt(1));
						System.out.println("name:" +resultSet.getString(2));
						
					}
					
				} else {
					System.out.println("not exist");

				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		
	}

}
