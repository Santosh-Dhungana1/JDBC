package com.qsp.sms.singlestring;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class SingleString {

	public static void main(String[] args) {
try {
	Class.forName("org.postgresql.Driver");
	Connection connection = DriverManager.getConnection("jdbc:postgresql://localhost:5432/first_db?user=postgres&password=root");
	Statement statement = connection.createStatement();
	 statement.execute("Insert into student values(11,'sanjay')");
	 connection.close();
	 System.out.println("Record Inserted successfully");
	
	} catch (ClassNotFoundException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
} catch (SQLException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
}
	}

}
