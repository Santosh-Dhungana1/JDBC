package com.qsp.sms.cbss;

import java.sql.Connection;
import java.sql.DriverManager;

public class Insert {

	public static void main(String[] args) {
		// TODO Auto-generated method 
	Class.forName("org.postgresql.Driver");
		Connection connection = DriverManager.getConnection("jdbc:postgresql://localhost:5432/first_db?url?user=postgres&password=root");
		)

	}

}.10010
